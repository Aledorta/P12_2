/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  * @author Alejandro Dorta Luis 
  * @date Nov 1 2023
  * @software license https://www.gnu.org/licenses/gpl-3.0.html
  * @brief El programa muestra por pantalla tanto el radio como el centro y color de un circulo, y si un punto se encuentra dentro o no
  * @bug There are no known bugs
  * 
  */
 
#include <iostream>
#include "complejo.h"

int main(int argc, char* argv[]) {
  double real1 = std::stod(argv[1]), real2 = std::stod(argv[3]);
  double imaginario1 = std::stod(argv[2]), imaginario2 = std::stod(argv[4]);
  Complejo complejo1{real1, imaginario1}, complejo2{real2, imaginario2};
  Complejo resultado;
  resultado = complejo1 + complejo2;
  std::cout << resultado << std::endl;
  resultado = complejo1 - complejo2;
  std::cout << resultado << std::endl;
}