/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  * @author Alejandro Dorta Luis 
  * @date Nov 1 2023
  * @software license https://www.gnu.org/licenses/gpl-3.0.html
  * @brief El programa muestra por pantalla tanto el radio como el centro y color de un circulo, y si un punto se encuentra dentro o no
  * @bug There are no known bugs
  * 
  */

#include <iostream>

#include "vehiculo.h"
#include "usuario.h"

int main() {
  Cliente cliente1("Juan");
  Administrador admin1("Admin1");
  Operador operador1("Operador1");

  Coche coche1(50.0, 3, 25.0);
  Motocicleta moto1(20.0, 5, 5.0);

  cliente1.alquilar_vehiculo(&coche1);
  cliente1.alquilar_vehiculo(&moto1);

  cliente1.mostrar_informacion();
  admin1.mostrar_informacion();
  operador1.mostrar_informacion();

  coche1.mostrar_informacion();
  moto1.mostrar_informacion();

  return 0;
}

