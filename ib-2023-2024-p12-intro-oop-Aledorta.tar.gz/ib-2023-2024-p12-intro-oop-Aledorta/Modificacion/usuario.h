/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  * @author Alejandro Dorta Luis 
  * @date Nov 1 2023
  * @software license https://www.gnu.org/licenses/gpl-3.0.html
  * @brief El programa muestra por pantalla tanto el radio como el centro y color de un circulo, y si un punto se encuentra dentro o no
  * @bug There are no known bugs
  * 
  */

#include <iostream>
#include <string>
#include <ctime>
#include <vector>

#include "vehiculo.h"

#pragma once

class Usuario {
  protected:
    std::string nombre;
    std::string tipo_usuario;

  public:
    Usuario(std::string n, std::string tu) : nombre(n), tipo_usuario(tu) {}

    void mostrar_informacion() {
        std::cout << "Nombre: " << nombre << ", Tipo de usuario: " << tipo_usuario << std::endl;
    }

    ~Usuario() {}
};

class Cliente : public Usuario {
  private:
    std::vector<Vehiculo*> vehiculos_alquilados;

  public:
    Cliente(std::string n) : Usuario(n, "Cliente") {}

    void alquilar_vehiculo(Vehiculo* vehiculo) {
      vehiculo->alquilar();
      vehiculos_alquilados.push_back(vehiculo);
    }

    void mostrar_informacion() {
      Usuario::mostrar_informacion();
      std::cout << "Vehículos alquilados: " << vehiculos_alquilados.size() << std::endl;
    }
};

class Administrador : public Usuario {
  public:
    Administrador(std::string n) : Usuario(n, "Administrador") {}

    void mostrar_informacion() {
      Usuario::mostrar_informacion();
    }
};

class Operador : public Usuario {
  public:
    Operador(std::string n) : Usuario(n, "Operador") {}

    void mostrar_informacion() {
      Usuario::mostrar_informacion();
    }
};