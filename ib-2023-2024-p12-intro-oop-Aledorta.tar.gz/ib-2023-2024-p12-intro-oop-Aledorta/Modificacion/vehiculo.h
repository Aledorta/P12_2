/**
  * Universidad de La Laguna
  * Escuela Superior de Ingeniería y Tecnología
  * Grado en Ingeniería Informática
  * Informática Básica 2023-2024
  * @author Alejandro Dorta Luis 
  * @date Nov 1 2023
  * @software license https://www.gnu.org/licenses/gpl-3.0.html
  * @brief El programa muestra por pantalla tanto el radio como el centro y color de un circulo, y si un punto se encuentra dentro o no
  * @bug There are no known bugs
  * 
  */

#include <iostream>
#include <string>
#include <ctime>

#pragma once

class Vehiculo {
  protected:
    std::string tipo;
    double costo_base;
    bool alquilado;

  public:
    Vehiculo(std::string t, double cb) : tipo(t), costo_base(cb) {}

    double calcular_costo_alquiler() {
      return 0.0; 
    }

    void mostrar_informacion() {
      std::cout << "Tipo: " << tipo << ", Costo base: " << costo_base << std::endl;
    }

    void alquilar() {
      alquilado = true;
    }

    void devolver() {
      alquilado = false;
    }

    ~Vehiculo() {}
};

class Coche : public Vehiculo {
  private:
    int dias_alquiler;
    double costo_diario;

  public:
    Coche(double cb, int da, double cd) : Vehiculo("Coche", cb), dias_alquiler(da), costo_diario(cd) {}

    double calcular_costo_alquiler() {
        return dias_alquiler * costo_diario;
    }

    void mostrar_informacion() {
      std::cout << "Tipo: " << tipo << ", Costo base: " << costo_base << ", Días de alquiler: " << dias_alquiler
                << ", Costo diario: " << costo_diario << ", Costo total: " << calcular_costo_alquiler() << std::endl;
    }
};

class Motocicleta : public Vehiculo {
  private:
    int horas_alquiler;
    double costo_por_hora;

  public:
    Motocicleta(double cb, int ha, double cph) : Vehiculo("Motocicleta", cb), horas_alquiler(ha), costo_por_hora(cph) {}

    double calcular_costo_alquiler() {
      return horas_alquiler * costo_por_hora;
    }

    void mostrar_informacion() {
      std::cout << "Tipo: " << tipo << ", Costo base: " << costo_base << ", Horas de alquiler: " << horas_alquiler
                << ", Costo por hora: " << costo_por_hora << ", Costo total: " << calcular_costo_alquiler() << std::endl;
    }
};

class Bicicleta : public Vehiculo {
  private:
    int horas_alquiler;
    double costo_por_hora;

  public:
    Bicicleta(double cb, int ha, double cph) : Vehiculo("Motocicleta", cb), horas_alquiler(ha), costo_por_hora(cph) {}

    double calcular_costo_alquiler() {
      return horas_alquiler * costo_por_hora;
    }

    void mostrar_informacion() {
      std::cout << "Tipo: " << tipo << ", Costo base: " << costo_base << ", Horas de alquiler: " << horas_alquiler
                << ", Costo por hora: " << costo_por_hora << ", Costo total: " << calcular_costo_alquiler() << std::endl;
    }
};

class Caravana : public Vehiculo {
  private:
    int semanas_alquiler;
    double costo_por_semana;

  public:
    Caravana(double cb, int ha, double cph) : Vehiculo("Motocicleta", cb), semanas_alquiler(ha), costo_por_semana(cph) {}

    double calcular_costo_alquiler() {
      return semanas_alquiler * costo_por_semana;
    }

    void mostrar_informacion() {
      std::cout << "Tipo: " << tipo << ", Costo base: " << costo_base << ", Horas de alquiler: " << semanas_alquiler
                << ", Costo por hora: " << costo_por_semana << ", Costo total: " << calcular_costo_alquiler() << std::endl;
    }
};

class Barco : public Vehiculo {
  private:
    int semanas_alquiler;
    double costo_por_semana;

  public:
    Barco(double cb, int ha, double cph) : Vehiculo("Motocicleta", cb), semanas_alquiler(ha), costo_por_semana(cph) {}

    double calcular_costo_alquiler() {
      return semanas_alquiler * costo_por_semana;
    }

    void mostrar_informacion() {
      std::cout << "Tipo: " << tipo << ", Costo base: " << costo_base << ", Horas de alquiler: " << semanas_alquiler
                << ", Costo por hora: " << costo_por_semana << ", Costo total: " << calcular_costo_alquiler() << std::endl;
    }
};